#!C:/Users/admin/AppData/Local/Programs/Python/Python38/python.exe
import redis

r = redis.Redis(host='localhost', port=6379, db=0)
r.set('foo', 'bar')
x = r.get('foo')
print(x)
