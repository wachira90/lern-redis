import os
# os.system('ls -l')
os.system('dir')