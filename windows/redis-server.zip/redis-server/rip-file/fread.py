f = open("C:\\redis-server\\rip-file\\demofile.txt", "r")
print(f.read())