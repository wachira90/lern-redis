import hashlib

for i in range(60):
    x = hashlib.new("md5")
    x.update(b"Nobody inspects the")
    print(x.hexdigest())
    # print(x)