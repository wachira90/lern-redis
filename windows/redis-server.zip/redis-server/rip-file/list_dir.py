import os

# List all subdirectories using os.listdir
basepath = 'mydir/'
for entry in os.listdir(basepath):
    if os.path.isdir(os.path.join(basepath, entry)):
        print(entry)