import hashlib

for i in range(6):
    x = hashlib.sha256(b"Nobody inspects the spammish repetition")
    print(x.hexdigest() , i + 1)
    # print(x)