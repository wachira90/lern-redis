f=open("C:\\redis-server\\rip-file\\binfile.txt", mode="rb")
num=list(f.read())
print (num)
f.close()

#,mode="rb",encoding="utf-8"