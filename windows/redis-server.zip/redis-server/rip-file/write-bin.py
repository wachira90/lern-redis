#WRITE BINARY
f=open("C:\\redis-server\\rip-file\\binfile.txt","wb")
num=[5, 10, 15, 20, 25]
arr=bytearray(num)
f.write(arr)
f.close()


