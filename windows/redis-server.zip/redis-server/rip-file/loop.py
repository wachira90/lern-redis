# fruits = ["apple", "banana", "cherry"]
# for x in fruits:
#   print(x)

for x in range(6):
  print(x)