const express = require('express')
const fetch = require("node-fetch");
const redis = require('redis')
 
const app = express()
 
const client = redis.createClient(6379)
 
client.on('error', (err) => {
    console.log("Error " + err)
});

app.get('/photos', (req, res) => {
 
    const photosRedisKey = 'user:photos';
 
    return client.get(photosRedisKey, (err, photos) => {
 
        if (photos) {
            console.log(">> CACHE >>")
            return res.json({ source: 'cache', data: JSON.parse(photos) })
 
        } else { // Key does not exist in Redis store
            console.log(">> NO CACHE >>")
            fetch('https://jsonplaceholder.typicode.com/photos')
                .then(response => response.json())
                .then(photos => {
 
                    // Save the  API response in Redis store,  data expire time in 3600 seconds, it means one hour
                    client.setex(photosRedisKey, 3600, JSON.stringify(photos))
 
                    return res.json({ source: 'api', data: photos })
 
                })
                .catch(error => {
                    console.log(error)
                    return res.json(error.toString())
                })
        }
    });
});
//https://jsonplaceholder.typicode.com/albums

app.get('/albums', (req, res) => {
 
    const photosRedisKey = 'user:albums';
 
    return client.get(photosRedisKey, (err, albums) => {
 
        if (albums) {
            console.log(">> CACHE >>")
            return res.json({ source: 'cache', data: JSON.parse(albums) })
 
        } else { // Key does not exist in Redis store
            console.log(">> NO CACHE >>")
            fetch('https://jsonplaceholder.typicode.com/albums')
                .then(response => response.json())
                .then(albums => {
 
                    // Save the  API response in Redis store,  data expire time in 3600 seconds, it means one hour
                    client.setex(photosRedisKey, 3600, JSON.stringify(albums))
 
                    return res.json({ source: 'api', data: albums })
 
                })
                .catch(error => {
                    console.log(error)
                    return res.json(error.toString())
                })
        }
    });
});


 
// start express server at 3000 port
app.listen(3000, () => {
    console.log('Server listening on port: ', 3000)
});